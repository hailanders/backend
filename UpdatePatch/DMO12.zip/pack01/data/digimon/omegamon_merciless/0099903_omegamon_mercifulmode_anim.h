// This file was automatically generated. It contains definitions for all the
// animations stored in the associated KFM file. Include this file in your
// final application to easily refer to animation sequences.

#ifndef 0099903_OMEGAMON_MERCIFULMODE_ANIM_H__
#define 0099903_OMEGAMON_MERCIFULMODE_ANIM_H__

namespace 0099903_Omegamon_Mercifulmode_Anim
{
    enum
    {
        ARUN                    = 901203,
        BLOCK                   = 901504,
        BUFF                    = 901321,
        DIE                     = 901509,
        DOWN                    = 901703,
        EVO01                   = 901701,
        EVO02                   = 901702,
        HIT01                   = 901301,
        HIT02                   = 901302,
        HRE                     = 901102,
        IDLE                    = 901101,
        IDLEC                   = 901104,
        LQUA                    = 901501,
        MISS                    = 901503,
        MSK                     = 901505,
        RIDEIDLE                = 901211,
        RIDERUN                 = 901212,
        RQUA                    = 901502,
        RUN                     = 901202,
        SHK                     = 901103,
        SKILL01                 = 901311,
        SKILL02                 = 901312,
        SKILL03                 = 901313,
        SKILL04                 = 901314,
        WALK                    = 901201
    };
}

#endif  // #ifndef 0099903_OMEGAMON_MERCIFULMODE_ANIM_H__
